import SwiftUI
import AVFoundation
import MediaPlayer
import Combine

@main
struct LaneApp: App {
    @StateObject private var session = SessionStore()
    @StateObject private var player = PlayerStore()
    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(session)
                .environmentObject(player)
                .preferredColorScheme(.dark)
        }
    }
}

// MARK: - Models
struct Track: Identifiable, Hashable, Codable {
    let id: String
    var title: String
    var artist: String
    var album: String?
    var artworkURL: String?
    var streamURL: String?
    var duration: Double?
}
struct Album: Identifiable, Hashable { let id: String; let title: String; let artist: String; let artworkURL: String? }
struct Artist: Identifiable, Hashable { let id: String; let name: String; let artworkURL: String? }
struct Playlist: Identifiable, Hashable {
    let id: String
    var name: String
    var description: String?
    var imageURL: String?
    var tracks: [Track]
}
struct LaneUser: Codable, Hashable { var id: String; var username: String; var avatarURL: String? }
struct LaneNotification: Identifiable { let id: String; let title: String; let body: String; let date: Date }

// MARK: - API
actor LaneAPI {
    static let shared = LaneAPI()
    private let base = URL(string: "https://laneapi.com")!
    private let session = URLSession.shared

    private func request(_ path: String, method: String = "GET", query: [URLQueryItem] = [], body: Any? = nil, token: String? = nil) async throws -> Data {
        var components = URLComponents(url: base.appendingPathComponent(path.trimmingCharacters(in: CharacterSet(charactersIn: "/"))), resolvingAgainstBaseURL: false)!
        components.queryItems = query.isEmpty ? nil : query
        var r = URLRequest(url: components.url!)
        r.httpMethod = method
        r.setValue("application/json", forHTTPHeaderField: "Accept")
        if let body { r.setValue("application/json", forHTTPHeaderField: "Content-Type"); r.httpBody = try JSONSerialization.data(withJSONObject: body) }
        if let token, !token.isEmpty { r.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization") }
        let (data, response) = try await session.data(for: r)
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else { throw URLError(.badServerResponse) }
        return data
    }

    func home(token: String?) async throws -> Data { try await request("/feed/home", token: token) }
    func search(_ query: String, token: String?) async throws -> Data { try await request("/platforms/search", query: [URLQueryItem(name: "q", value: query)], token: token) }
    func user(token: String) async throws -> Data { try await request("/user-info", token: token) }
    func playlists(token: String) async throws -> Data { try await request("/user/playlists", token: token) }
    func playlist(id: String, token: String) async throws -> Data { try await request("/playlist/\(id)", token: token) }
    func createPlaylist(name: String, token: String) async throws -> Data { try await request("/create-playlist", method: "POST", body: ["name": name], token: token) }
    func deletePlaylist(id: String, token: String) async throws -> Data { try await request("/delete-playlist", method: "POST", body: ["playlistId": id], token: token) }
    func addTrack(_ track: Track, to playlist: String, token: String) async throws -> Data { try await request("/user/playlist/add", method: "POST", body: ["playlistId": playlist, "trackId": track.id], token: token) }
    func removeTrack(_ track: Track, from playlist: String, token: String) async throws -> Data { try await request("/user/playlist/remove-track", method: "POST", body: ["playlistId": playlist, "trackId": track.id], token: token) }
    func recent(token: String) async throws -> Data { try await request("/user/recent", token: token) }
    func favorites(token: String) async throws -> Data { try await request("/user/tracks", token: token) }
    func artists(token: String) async throws -> Data { try await request("/user/artists", token: token) }
    func albums(token: String) async throws -> Data { try await request("/user/albums", token: token) }
    func historyDelete(id: String, token: String) async throws -> Data { try await request("/user/history-delete-item", method: "POST", body: ["id": id], token: token) }
    func trackStream(id: String, token: String) async throws -> Data { try await request("/track/stream", method: "POST", body: ["trackId": id], token: token) }
}

// MARK: - Session
@MainActor final class SessionStore: ObservableObject {
    @Published var token = UserDefaults.standard.string(forKey: "lane.token") ?? ""
    @Published var user: LaneUser?
    @Published var isLoading = false
    @Published var error: String?
    var isSignedIn: Bool { !token.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }

    func signIn(token: String) { self.token = token.trimmingCharacters(in: .whitespacesAndNewlines); UserDefaults.standard.set(self.token, forKey: "lane.token") }
    func signOut() { token = ""; user = nil; UserDefaults.standard.removeObject(forKey: "lane.token") }
    func loadUser() async {
        guard isSignedIn else { return }
        do { user = try decodeUser(try await LaneAPI.shared.user(token: token)) }
        catch { self.error = "Не удалось загрузить профиль" }
    }
}

// MARK: - Player
@MainActor final class PlayerStore: ObservableObject {
    @Published var current: Track?
    @Published var isPlaying = false
    @Published var progress = 0.0
    @Published var queue: [Track] = []
    private let player = AVPlayer()
    private var observer: Any?
    init() {
        try? AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
        try? AVAudioSession.sharedInstance().setActive(true)
        observer = player.addPeriodicTimeObserver(forInterval: CMTime(seconds: 0.25, preferredTimescale: 600), queue: .main) { [weak self] time in
            Task { @MainActor in self?.progress = time.seconds }
        }
    }
    deinit { if let observer { player.removeTimeObserver(observer) } }
    func play(_ track: Track) {
        current = track
        guard let raw = track.streamURL, let url = URL(string: raw) else { return }
        player.replaceCurrentItem(with: AVPlayerItem(url: url)); player.play(); isPlaying = true
    }
    func toggle() { isPlaying ? player.pause() : player.play(); isPlaying.toggle() }
    func next() { guard !queue.isEmpty else { return }; if let current, let i = queue.firstIndex(of: current), i + 1 < queue.count { play(queue[i + 1]) } }
    func stop() { player.pause(); isPlaying = false }
}

// MARK: - Root / Auth
struct RootView: View {
    @EnvironmentObject var session: SessionStore
    var body: some View { Group { session.isSignedIn ? AnyView(MainView()) : AnyView(LoginView()) }.task { await session.loadUser() } }
}
struct LoginView: View {
    @EnvironmentObject var session: SessionStore
    @State private var token = ""
    var body: some View {
        ZStack {
            LinearGradient(colors: [.black, Color(red: 0.12, green: 0.03, blue: 0.20)], startPoint: .top, endPoint: .bottom).ignoresSafeArea()
            VStack(spacing: 18) {
                Image(systemName: "waveform.circle.fill").font(.system(size: 76)).foregroundStyle(.purple)
                Text("Lane").font(.system(size: 42, weight: .bold))
                Text("Музыка, плейлисты и библиотека").foregroundStyle(.secondary).multilineTextAlignment(.center)
                SecureField("Токен Lane", text: $token).textFieldStyle(.roundedBorder).textInputAutocapitalization(.never)
                Button("Войти") { session.signIn(token: token) }.buttonStyle(.borderedProminent).disabled(token.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                Link("Lane API", destination: URL(string: "https://laneapi.com")!).foregroundStyle(.secondary)
            }.padding(28)
        }
    }
}

// MARK: - Main
struct MainView: View {
    @EnvironmentObject var player: PlayerStore
    @State private var tab = 0
    var body: some View {
        TabView(selection: $tab) {
            HomeView().tabItem { Label("Главная", systemImage: "house.fill") }.tag(0)
            SearchView().tabItem { Label("Поиск", systemImage: "magnifyingglass") }.tag(1)
            LibraryView().tabItem { Label("Библиотека", systemImage: "music.note.list") }.tag(2)
            ProfileView().tabItem { Label("Профиль", systemImage: "person.crop.circle") }.tag(3)
        }
        .safeAreaInset(edge: .bottom) { if player.current != nil { MiniPlayer().padding(.horizontal, 8) } }
    }
}

struct HomeView: View {
    @EnvironmentObject var session: SessionStore; @EnvironmentObject var player: PlayerStore
    @State private var tracks: [Track] = []; @State private var recent: [Track] = []; @State private var loading = true
    var body: some View {
        NavigationStack { ScrollView { LazyVStack(alignment: .leading, spacing: 18) {
            Text("Главная").font(.largeTitle.bold())
            SectionTitle("Рекомендации")
            if loading { ProgressView().frame(maxWidth: .infinity).padding(30) } else if tracks.isEmpty { EmptyState(title: "Нет рекомендаций", icon: "music.note") } else { ForEach(tracks) { track in TrackRow(track: track) { player.play(track) } } }
            if !recent.isEmpty { SectionTitle("Недавнее"); ForEach(recent) { track in TrackRow(track: track) { player.play(track) } } }
        }.padding() }.navigationTitle("").task { await load() }.refreshable { await load() } }
    }
    func load() async { loading = true; defer { loading = false }; guard session.isSignedIn else { return }; tracks = parseTracks((try? await LaneAPI.shared.home(token: session.token)) ?? Data()); recent = parseTracks((try? await LaneAPI.shared.recent(token: session.token)) ?? Data()) }
}

struct SearchView: View {
    @EnvironmentObject var session: SessionStore; @EnvironmentObject var player: PlayerStore
    @State private var query = ""; @State private var results: [Track] = []; @State private var searching = false
    var body: some View {
        NavigationStack { List { if searching { ProgressView() } else { ForEach(results) { track in TrackRow(track: track) { player.play(track) }.listRowBackground(Color.clear) } } }.scrollContentBackground(.hidden).navigationTitle("Поиск").searchable(text: $query, prompt: "Треки, артисты, альбомы").onSubmit(of: .search) { Task { await search() } } }
    }
    func search() async { guard session.isSignedIn, !query.isEmpty else { return }; searching = true; defer { searching = false }; results = parseTracks((try? await LaneAPI.shared.search(query, token: session.token)) ?? Data()) }
}

struct LibraryView: View {
    @EnvironmentObject var session: SessionStore
    @State private var playlists: [Playlist] = []; @State private var favorites: [Track] = []; @State private var recent: [Track] = []; @State private var showingCreate = false
    var body: some View {
        NavigationStack { List {
            Section("Плейлисты") { ForEach(playlists) { p in NavigationLink { PlaylistView(playlist: p) } label: { Label(p.name, systemImage: "music.note.list") } } }
            Section("Моя музыка") { NavigationLink { TrackListView(title: "Любимые треки", tracks: favorites) } label: { Label("Любимые треки", systemImage: "heart.fill") }; NavigationLink { TrackListView(title: "История", tracks: recent) } label: { Label("История", systemImage: "clock") } }
            Section("Каталог") { NavigationLink { ArtistsView() } label: { Label("Артисты", systemImage: "person.2.fill") }; NavigationLink { AlbumsView() } label: { Label("Альбомы", systemImage: "square.stack") } }
            Section("Импорт") { NavigationLink { ImportView() } label: { Label("Импорт из Telegram", systemImage: "arrow.down.circle") } }
        }.navigationTitle("Библиотека").toolbar { Button { showingCreate = true } label: { Image(systemName: "plus") } }.task { await load() }.sheet(isPresented: $showingCreate) { CreatePlaylistView { await load() } } }
    }
    func load() async { guard session.isSignedIn else { return }; playlists = parsePlaylists((try? await LaneAPI.shared.playlists(token: session.token)) ?? Data()); favorites = parseTracks((try? await LaneAPI.shared.favorites(token: session.token)) ?? Data()); recent = parseTracks((try? await LaneAPI.shared.recent(token: session.token)) ?? Data()) }
}

struct TrackListView: View { let title: String; let tracks: [Track]; @EnvironmentObject var player: PlayerStore; var body: some View { List(tracks) { track in TrackRow(track: track) { player.play(track) } }.navigationTitle(title) } }
struct PlaylistView: View { let playlist: Playlist; @EnvironmentObject var player: PlayerStore; var body: some View { List(playlist.tracks) { track in TrackRow(track: track) { player.play(track) } }.navigationTitle(playlist.name) } }
struct ArtistsView: View { @EnvironmentObject var session: SessionStore; @State private var artists: [Artist] = []; var body: some View { List(artists) { a in Label(a.name, systemImage: "person.circle") }.navigationTitle("Артисты").task { artists = parseArtists((try? await LaneAPI.shared.artists(token: session.token)) ?? Data()) } } }
struct AlbumsView: View { @EnvironmentObject var session: SessionStore; @State private var albums: [Album] = []; var body: some View { List(albums) { a in Label("\(a.title) — \(a.artist)", systemImage: "square.stack") }.navigationTitle("Альбомы").task { albums = parseAlbums((try? await LaneAPI.shared.albums(token: session.token)) ?? Data()) } } }

struct CreatePlaylistView: View {
    @Environment(\.dismiss) var dismiss; @EnvironmentObject var session: SessionStore; @State private var name = ""; let reload: () async -> Void
    var body: some View { NavigationStack { Form { TextField("Название", text: $name) }.navigationTitle("Новый плейлист").toolbar { ToolbarItem(placement: .cancellationAction) { Button("Отмена") { dismiss() } }; ToolbarItem(placement: .confirmationAction) { Button("Создать") { Task { await create() } }.disabled(name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty) } } } }
    func create() async { guard session.isSignedIn else { return }; _ = try? await LaneAPI.shared.createPlaylist(name: name, token: session.token); await reload(); dismiss() }
}

// MARK: - Profile and secondary features
struct ProfileView: View {
    @EnvironmentObject var session: SessionStore
    var body: some View { NavigationStack { List {
        Section { HStack(spacing: 14) { Image(systemName: "person.crop.circle.fill").font(.system(size: 58)); VStack(alignment: .leading) { Text(session.user?.username ?? "Lane пользователь").font(.title2.bold()); Text("Профиль").foregroundStyle(.secondary) } } }
        Section("Настройки") { NavigationLink("Аудио", destination: AudioSettingsView()); NavigationLink("Уведомления", destination: NotificationsView()); NavigationLink("Комментарии", destination: CommentsView()); NavigationLink("Premium", destination: PremiumView()); NavigationLink("О приложении", destination: AboutView()) }
        Button("Выйти", role: .destructive) { session.signOut() }
    }.navigationTitle("Профиль").task { await session.loadUser() } } }
}
struct AudioSettingsView: View { @AppStorage("lane.quality") private var quality = "Высокое"; @AppStorage("lane.normalize") private var normalize = true; var body: some View { Form { Picker("Качество", selection: $quality) { Text("Авто").tag("Авто"); Text("Высокое").tag("Высокое"); Text("Максимальное").tag("Максимальное") }; Toggle("Нормализация", isOn: $normalize); Toggle("Эквалайзер", isOn: .constant(false)) }.navigationTitle("Аудио") } }
struct NotificationsView: View { @AppStorage("lane.releases") private var releases = true; @AppStorage("lane.comments") private var comments = true; var body: some View { Form { Toggle("Новые релизы", isOn: $releases); Toggle("Комментарии", isOn: $comments); Toggle("Подписки", isOn: .constant(true)); Toggle("Друзья онлайн", isOn: .constant(false)) }.navigationTitle("Уведомления") } }
struct CommentsView: View { var body: some View { VStack(spacing: 12) { Image(systemName: "text.bubble").font(.system(size: 48)); Text("Комментарии").font(.title2.bold()); Text("Комментарии и ответы доступны из экранов треков.").foregroundStyle(.secondary).multilineTextAlignment(.center) }.padding().navigationTitle("Комментарии") } }
struct PremiumView: View { var body: some View { VStack(spacing: 18) { Image(systemName: "crown.fill").font(.system(size: 64)); Text("Lane Premium").font(.largeTitle.bold()); Text("Высокое качество, дополнительные возможности и расширенные функции.").multilineTextAlignment(.center).foregroundStyle(.secondary); Link("Условия Premium", destination: URL(string: "https://sk-lane.com/premium-terms")!).buttonStyle(.borderedProminent) }.padding().navigationTitle("Premium") } }
struct ImportView: View { var body: some View { VStack(spacing: 14) { Image(systemName: "arrow.down.circle").font(.system(size: 56)); Text("Импорт из Telegram").font(.title2.bold()); Text("Открой Telegram-бот Lane для авторизации и импорта библиотеки.").multilineTextAlignment(.center).foregroundStyle(.secondary); Link("Открыть Lane bot", destination: URL(string: "https://t.me/lane_music_bot?start=auth")!).buttonStyle(.borderedProminent) }.padding().navigationTitle("Импорт") } }
struct AboutView: View { var body: some View { List { LabeledContent("Версия", value: "1.0.0 iOS"); Link("Условия использования", destination: URL(string: "https://sk-lane.com/terms-of-service")!); Link("Политика конфиденциальности", destination: URL(string: "https://sk-lane.com/privacy-policy")!); Link("Premium", destination: URL(string: "https://sk-lane.com/premium-terms")!); Link("EULA", destination: URL(string: "https://sk-lane.com/eula")!) }.navigationTitle("О приложении") } }

// MARK: - Components
struct SectionTitle: View { let title: String; init(_ title: String) { self.title = title }; var body: some View { Text(title).font(.title2.bold()) } }
struct TrackRow: View { let track: Track; let action: () -> Void; var body: some View { Button(action: action) { HStack(spacing: 12) { AsyncImage(url: URL(string: track.artworkURL ?? "")) { image in image.resizable().scaledToFill() } placeholder: { RoundedRectangle(cornerRadius: 8).fill(.gray.opacity(0.18)) }.frame(width: 52, height: 52).clipShape(RoundedRectangle(cornerRadius: 8)); VStack(alignment: .leading, spacing: 3) { Text(track.title).font(.headline).lineLimit(1); Text(track.artist).font(.subheadline).foregroundStyle(.secondary).lineLimit(1); if let album = track.album { Text(album).font(.caption).foregroundStyle(.tertiary).lineLimit(1) } }; Spacer(); Image(systemName: "play.fill").foregroundStyle(.secondary) }.contentShape(Rectangle()) }.buttonStyle(.plain) } }
struct MiniPlayer: View { @EnvironmentObject var player: PlayerStore; var body: some View { HStack { Image(systemName: "music.note").frame(width: 40, height: 40).background(.thinMaterial).clipShape(RoundedRectangle(cornerRadius: 8)); VStack(alignment: .leading) { Text(player.current?.title ?? "").lineLimit(1); Text(player.current?.artist ?? "").font(.caption).foregroundStyle(.secondary) }; Spacer(); Button { player.toggle() } label: { Image(systemName: player.isPlaying ? "pause.fill" : "play.fill") }; Button { player.next() } label: { Image(systemName: "forward.fill") } }.padding(10).background(.ultraThinMaterial).clipShape(RoundedRectangle(cornerRadius: 14)) } }
struct EmptyState: View { let title: String; let icon: String; var body: some View { VStack(spacing: 10) { Image(systemName: icon).font(.system(size: 42)); Text(title).foregroundStyle(.secondary) }.frame(maxWidth: .infinity).padding(50) } }

// MARK: - Flexible JSON parsing (API responses differ between versions)
func dictionaries(_ data: Data, keys: [String]) -> [[String: Any]] {
    guard let object = try? JSONSerialization.jsonObject(with: data) else { return [] }
    if let a = object as? [[String: Any]] { return a }
    if let d = object as? [String: Any] { for key in keys { if let a = d[key] as? [[String: Any]] { return a } } }
    return []
}
func string(_ x: [String: Any], _ keys: [String], fallback: String = "") -> String { for k in keys { if let s = x[k] as? String { return s }; if let n = x[k] as? NSNumber { return n.stringValue } }; return fallback }
func track(_ x: [String: Any]) -> Track { Track(id: string(x,["id","trackId"],fallback: UUID().uuidString), title: string(x,["title","name"],fallback:"Без названия"), artist: string(x,["artistName","artist"],fallback:"Неизвестный артист"), album: string(x,["albumName","album"]).isEmpty ? nil : string(x,["albumName","album"]), artworkURL: string(x,["artworkUrl","coverUrl","imageUrl"]).isEmpty ? nil : string(x,["artworkUrl","coverUrl","imageUrl"]), streamURL: string(x,["streamUrl","stream","url"]).isEmpty ? nil : string(x,["streamUrl","stream","url"]), duration: (x["duration"] as? NSNumber)?.doubleValue) }
func parseTracks(_ data: Data) -> [Track] { dictionaries(data, keys: ["tracks","items","results","data","recommendations"]).map(track) }
func parsePlaylists(_ data: Data) -> [Playlist] { dictionaries(data, keys: ["playlists","items","data"]).map { x in Playlist(id: string(x,["id","playlistId"],fallback:UUID().uuidString), name: string(x,["name","title"],fallback:"Плейлист"), description: string(x,["description"]).isEmpty ? nil : string(x,["description"]), imageURL: string(x,["imageUrl","coverUrl"]).isEmpty ? nil : string(x,["imageUrl","coverUrl"]), tracks: parseTracks(tryJSON(x["tracks"])) ) } }
func parseArtists(_ data: Data) -> [Artist] { dictionaries(data, keys: ["artists","items","data","results"]).map { Artist(id: string($0,["id"],fallback:UUID().uuidString), name: string($0,["name","title"],fallback:"Артист"), artworkURL: string($0,["imageUrl","avatarUrl"]).isEmpty ? nil : string($0,["imageUrl","avatarUrl"])) } }
func parseAlbums(_ data: Data) -> [Album] { dictionaries(data, keys: ["albums","items","data","results"]).map { Album(id: string($0,["id"],fallback:UUID().uuidString), title: string($0,["name","title"],fallback:"Альбом"), artist: string($0,["artistName","artist"],fallback:"Неизвестный артист"), artworkURL: string($0,["imageUrl","coverUrl"]).isEmpty ? nil : string($0,["imageUrl","coverUrl"])) } }
func tryJSON(_ value: Any?) -> Data { guard JSONSerialization.isValidJSONObject(value as Any) else { return Data() }; return (try? JSONSerialization.data(withJSONObject: value as Any)) ?? Data() }
func decodeUser(_ data: Data) throws -> LaneUser { if let user = try? JSONDecoder().decode(LaneUser.self, from: data) { return user }; let x = dictionaries(data, keys:["user","data"]).first ?? [:]; return LaneUser(id: string(x,["id"],fallback:"0"), username: string(x,["username","name"],fallback:"Lane пользователь"), avatarURL: string(x,["avatarUrl","imageUrl"]).isEmpty ? nil : string(x,["avatarUrl","imageUrl"])) }
