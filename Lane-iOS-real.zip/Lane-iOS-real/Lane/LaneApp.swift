import SwiftUI
import AVFoundation
import MediaPlayer

@main
struct LaneApp: App {
    @StateObject private var session = SessionStore()
    @StateObject private var player = PlayerStore()
    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(session)
                .environmentObject(player)
                .preferredColorScheme(.dark)
        }
    }
}

// MARK: - Models
struct Track: Identifiable, Codable, Hashable {
    let id: String
    var title: String
    var artist: String
    var album: String?
    var artworkURL: String?
    var streamURL: String?
    var duration: Double?
}
struct Playlist: Identifiable, Codable, Hashable {
    let id: String
    var name: String
    var description: String?
    var imageURL: String?
    var tracks: [Track]
}
struct LaneUser: Codable, Hashable {
    var id: String
    var username: String
    var avatarURL: String?
}

// MARK: - API
actor LaneAPI {
    static let shared = LaneAPI()
    private let base = URL(string: "https://laneapi.com")!
    private let session = URLSession.shared
    private func request(_ path: String, method: String = "GET", body: Data? = nil, token: String? = nil) async throws -> Data {
        var r = URLRequest(url: base.appendingPathComponent(path.trimmingCharacters(in: CharacterSet(charactersIn: "/"))))
        r.httpMethod = method
        r.setValue("application/json", forHTTPHeaderField: "Accept")
        if body != nil { r.setValue("application/json", forHTTPHeaderField: "Content-Type") }
        if let token { r.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization") }
        r.httpBody = body
        let (data, response) = try await session.data(for: r)
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            throw URLError(.badServerResponse)
        }
        return data
    }
    func home(token: String?) async throws -> Data { try await request("/feed/home", token: token) }
    func search(_ query: String, token: String?) async throws -> Data {
        let q = query.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? query
        var r = URLRequest(url: base.appendingPathComponent("platforms/search").appending(queryItems: [URLQueryItem(name: "q", value: q)]))
        r.setValue("application/json", forHTTPHeaderField: "Accept")
        if let token { r.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization") }
        let (data, response) = try await session.data(for: r)
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else { throw URLError(.badServerResponse) }
        return data
    }
    func playlists(token: String) async throws -> Data { try await request("/user/playlists", token: token) }
    func user(token: String) async throws -> Data { try await request("/user-info", token: token) }
    func createPlaylist(name: String, token: String) async throws -> Data {
        let body = try JSONSerialization.data(withJSONObject: ["name": name])
        return try await request("/create-playlist", method: "POST", body: body, token: token)
    }
}

// MARK: - Session
@MainActor final class SessionStore: ObservableObject {
    @Published var token: String? = UserDefaults.standard.string(forKey: "lane.token")
    @Published var user: LaneUser?
    @Published var isLoading = false
    @Published var error: String?
    var isSignedIn: Bool { token != nil }
    func signIn(token: String) { self.token = token; UserDefaults.standard.set(token, forKey: "lane.token") }
    func signOut() { token = nil; user = nil; UserDefaults.standard.removeObject(forKey: "lane.token") }
    func loadUser() async {
        guard let token else { return }
        do {
            let data = try await LaneAPI.shared.user(token: token)
            if let decoded = try? JSONDecoder().decode(LaneUser.self, from: data) { user = decoded }
        } catch { error = "Не удалось загрузить профиль" }
    }
}

// MARK: - Player
@MainActor final class PlayerStore: ObservableObject {
    @Published var current: Track?
    @Published var isPlaying = false
    @Published var progress: Double = 0
    @Published var queue: [Track] = []
    private var player = AVPlayer()
    private var observer: Any?
    init() {
        try? AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
        try? AVAudioSession.sharedInstance().setActive(true)
    }
    func play(_ track: Track) {
        current = track
        guard let raw = track.streamURL, let url = URL(string: raw) else { return }
        player.replaceCurrentItem(with: AVPlayerItem(url: url))
        player.play(); isPlaying = true
        if observer == nil {
            observer = player.addPeriodicTimeObserver(forInterval: CMTime(seconds: 0.25, preferredTimescale: 600), queue: .main) { [weak self] t in
                self?.progress = t.seconds
            }
        }
    }
    func toggle() { isPlaying ? player.pause() : player.play(); isPlaying.toggle() }
    func stop() { player.pause(); isPlaying = false }
}

// MARK: - Root
struct RootView: View {
    @EnvironmentObject var session: SessionStore
    var body: some View {
        Group {
            if session.isSignedIn { MainView() } else { LoginView() }
        }
    }
}

struct LoginView: View {
    @EnvironmentObject var session: SessionStore
    @State private var token = ""
    @State private var showHelp = false
    var body: some View {
        ZStack {
            LinearGradient(colors: [.black, Color(red: 0.12, green: 0.03, blue: 0.20)], startPoint: .top, endPoint: .bottom).ignoresSafeArea()
            VStack(spacing: 22) {
                Image(systemName: "waveform.circle.fill").font(.system(size: 76)).foregroundStyle(.purple)
                Text("Lane").font(.system(size: 42, weight: .bold))
                Text("Музыка, плейлисты и твоя библиотека").foregroundStyle(.secondary).multilineTextAlignment(.center)
                SecureField("Lane token", text: $token).textFieldStyle(.roundedBorder).autocorrectionDisabled()
                Button("Войти") { session.signIn(token: token.trimmingCharacters(in: .whitespacesAndNewlines)) }
                    .buttonStyle(.borderedProminent).disabled(token.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                Button("Как получить токен?") { showHelp = true }.foregroundStyle(.secondary)
            }.padding(28)
        }
        .alert("Авторизация Lane", isPresented: $showHelp) { Button("OK", role: .cancel) {} } message: {
            Text("iOS-версия использует токен Lane API. Когда подключим нативный auth-flow из Android-версии, эта форма будет заменена полноценным входом.")
        }
    }
}

struct MainView: View {
    @EnvironmentObject var session: SessionStore
    @EnvironmentObject var player: PlayerStore
    @State private var tab = 0
    var body: some View {
        TabView(selection: $tab) {
            HomeView().tabItem { Label("Главная", systemImage: "house.fill") }.tag(0)
            SearchView().tabItem { Label("Поиск", systemImage: "magnifyingglass") }.tag(1)
            LibraryView().tabItem { Label("Библиотека", systemImage: "music.note.list") }.tag(2)
            ProfileView().tabItem { Label("Профиль", systemImage: "person.crop.circle") }.tag(3)
        }
        .safeAreaInset(edge: .bottom) { if player.current != nil { MiniPlayer().padding(.horizontal, 8) } }
    }
}

struct HomeView: View {
    @EnvironmentObject var session: SessionStore
    @State private var tracks: [Track] = []
    @State private var loading = true
    @EnvironmentObject var player: PlayerStore
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    Text("Главная").font(.largeTitle.bold())
                    if loading { ProgressView().frame(maxWidth: .infinity).padding(50) }
                    else if tracks.isEmpty { EmptyState(title: "Пока нет рекомендаций", icon: "music.note") }
                    else {
                        Text("Рекомендации").font(.title2.bold())
                        ForEach(tracks) { TrackRow(track: $0) { player.play($0) } }
                    }
                }.padding()
            }.task { await load() }.refreshable { await load() }
        }
    }
    func load() async {
        loading = true
        defer { loading = false }
        guard let token = session.token else { return }
        do {
            let data = try await LaneAPI.shared.home(token: token)
            tracks = parseTracks(data)
        } catch { }
    }
}

struct SearchView: View {
    @EnvironmentObject var session: SessionStore
    @EnvironmentObject var player: PlayerStore
    @State private var query = ""
    @State private var results: [Track] = []
    var body: some View {
        NavigationStack {
            List {
                if results.isEmpty && !query.isEmpty { Text("Ничего не найдено").foregroundStyle(.secondary) }
                ForEach(results) { TrackRow(track: $0) { player.play($0) }.listRowBackground(Color.clear) }
            }.scrollContentBackground(.hidden)
            .navigationTitle("Поиск")
            .searchable(text: $query, prompt: "Треки, артисты, альбомы")
            .onSubmit(of: .search) { Task { await search() } }
        }
    }
    func search() async {
        guard let token = session.token, !query.isEmpty else { return }
        if let data = try? await LaneAPI.shared.search(query, token: token) { results = parseTracks(data) }
    }
}

struct LibraryView: View {
    @EnvironmentObject var session: SessionStore
    @State private var playlists: [Playlist] = []
    @State private var showingCreate = false
    var body: some View {
        NavigationStack {
            List {
                Section("Плейлисты") {
                    ForEach(playlists) { p in NavigationLink { PlaylistView(playlist: p) } label: { Label(p.name, systemImage: "music.note.list") } }
                }
                Section("Разделы") {
                    Label("Любимые треки", systemImage: "heart.fill")
                    Label("Артисты", systemImage: "person.2.fill")
                    Label("Альбомы", systemImage: "square.stack")
                    Label("Загрузки", systemImage: "arrow.down.circle")
                    Label("История", systemImage: "clock")
                }
            }.navigationTitle("Библиотека")
            .toolbar { Button { showingCreate = true } label: { Image(systemName: "plus") } }
            .task { await load() }
            .sheet(isPresented: $showingCreate) { CreatePlaylistView { await load() } }
        }
    }
    func load() async {
        guard let token = session.token, let data = try? await LaneAPI.shared.playlists(token: token) else { return }
        playlists = parsePlaylists(data)
    }
}

struct PlaylistView: View {
    let playlist: Playlist
    @EnvironmentObject var player: PlayerStore
    var body: some View {
        List(playlist.tracks) { TrackRow(track: $0) { player.play($0) } }
            .navigationTitle(playlist.name)
    }
}

struct CreatePlaylistView: View {
    @Environment(\.dismiss) var dismiss
    @EnvironmentObject var session: SessionStore
    @State private var name = ""
    let reload: () async -> Void
    var body: some View {
        NavigationStack {
            Form { TextField("Название", text: $name) }
                .navigationTitle("Новый плейлист")
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) { Button("Отмена") { dismiss() } }
                    ToolbarItem(placement: .confirmationAction) { Button("Создать") { Task { await create() } }.disabled(name.isEmpty) }
                }
        }
    }
    func create() async {
        guard let token = session.token else { return }
        _ = try? await LaneAPI.shared.createPlaylist(name: name, token: token)
        await reload(); dismiss()
    }
}

struct ProfileView: View {
    @EnvironmentObject var session: SessionStore
    var body: some View {
        NavigationStack {
            List {
                Section {
                    HStack(spacing: 14) { Image(systemName: "person.crop.circle.fill").font(.system(size: 58)); VStack(alignment: .leading) { Text(session.user?.username ?? "Lane пользователь").font(.title2.bold()); Text("Профиль").foregroundStyle(.secondary) } }
                }
                Section("Настройки") {
                    NavigationLink("Аудиокачество", destination: AudioSettingsView())
                    NavigationLink("Уведомления", destination: NotificationsView())
                    NavigationLink("Premium", destination: PremiumView())
                    NavigationLink("О приложении", destination: AboutView())
                }
                Button("Выйти", role: .destructive) { session.signOut() }
            }.navigationTitle("Профиль").task { await session.loadUser() }
        }
    }
}

struct MiniPlayer: View {
    @EnvironmentObject var player: PlayerStore
    var body: some View {
        HStack {
            Image(systemName: "music.note").frame(width: 40, height: 40).background(.thinMaterial).clipShape(RoundedRectangle(cornerRadius: 8))
            VStack(alignment: .leading) { Text(player.current?.title ?? "").lineLimit(1); Text(player.current?.artist ?? "").font(.caption).foregroundStyle(.secondary) }
            Spacer(); Button { player.toggle() } label: { Image(systemName: player.isPlaying ? "pause.fill" : "play.fill") }
        }.padding(10).background(.ultraThinMaterial).clipShape(RoundedRectangle(cornerRadius: 14))
    }
}

struct TrackRow: View {
    let track: Track
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            HStack(spacing: 12) {
                AsyncImage(url: URL(string: track.artworkURL ?? "")) { image in image.resizable().scaledToFill() } placeholder: { Color.gray.opacity(0.2) }
                    .frame(width: 52, height: 52).clipShape(RoundedRectangle(cornerRadius: 8))
                VStack(alignment: .leading, spacing: 3) { Text(track.title).font(.headline).lineLimit(1); Text(track.artist).font(.subheadline).foregroundStyle(.secondary).lineLimit(1); if let album = track.album { Text(album).font(.caption).foregroundStyle(.tertiary).lineLimit(1) } }
                Spacer(); Image(systemName: "play.fill").foregroundStyle(.secondary)
            }.contentShape(Rectangle())
        }.buttonStyle(.plain)
    }
}

struct AudioSettingsView: View { var body: some View { Form { Picker("Качество", selection: .constant("Высокое")) { Text("Авто").tag("Авто"); Text("Высокое").tag("Высокое"); Text("Максимальное").tag("Максимальное") }; Toggle("Нормализация", isOn: .constant(true)); Toggle("Эквалайзер", isOn: .constant(false)) }.navigationTitle("Аудио") } }
struct NotificationsView: View { var body: some View { List { Toggle("Новые релизы", isOn: .constant(true)); Toggle("Комментарии", isOn: .constant(true)); Toggle("Подписки", isOn: .constant(true)); Toggle("Друзья онлайн", isOn: .constant(false)) }.navigationTitle("Уведомления") } }
struct PremiumView: View { var body: some View { VStack(spacing: 18) { Image(systemName: "crown.fill").font(.system(size: 64)).foregroundStyle(.yellow); Text("Lane Premium").font(.largeTitle.bold()); Text("Дополнительные возможности, высокое качество и расширенные функции.").multilineTextAlignment(.center).foregroundStyle(.secondary); Button("Узнать больше") {}.buttonStyle(.borderedProminent) }.padding().navigationTitle("Premium") } }
struct AboutView: View { var body: some View { List { LabeledContent("Версия", value: "1.0"); Link("Условия использования", destination: URL(string: "https://sk-lane.com/terms-of-service")!); Link("Политика конфиденциальности", destination: URL(string: "https://sk-lane.com/privacy-policy")!); Link("Premium", destination: URL(string: "https://sk-lane.com/premium-terms")!) }.navigationTitle("О приложении") } }
struct EmptyState: View { let title: String; let icon: String; var body: some View { VStack(spacing: 10) { Image(systemName: icon).font(.system(size: 42)).foregroundStyle(.secondary); Text(title).foregroundStyle(.secondary) }.frame(maxWidth: .infinity).padding(50) } }

func parseTracks(_ data: Data) -> [Track] {
    guard let object = try? JSONSerialization.jsonObject(with: data) else { return [] }
    var candidates: [[String: Any]] = []
    if let a = object as? [[String: Any]] { candidates = a }
    if let d = object as? [String: Any] {
        for key in ["tracks", "items", "results", "data", "recommendations"] { if let a = d[key] as? [[String: Any]] { candidates.append(contentsOf: a) } }
    }
    return candidates.compactMap { x in
        let id = String(describing: x["id"] ?? x["trackId"] ?? UUID().uuidString)
        let title = String(describing: x["title"] ?? x["name"] ?? "Без названия")
        let artist: String
        if let a = x["artist"] as? String { artist = a } else if let a = x["artist"] as? [String: Any] { artist = String(describing: a["name"] ?? "Неизвестный артист") } else { artist = String(describing: x["artistName"] ?? "Неизвестный артист") }
        let album = x["album"] as? String ?? (x["album"] as? [String: Any]).flatMap { $0["name"] as? String }
        let art = x["artworkUrl"] as? String ?? x["coverUrl"] as? String ?? x["imageUrl"] as? String
        let stream = x["streamUrl"] as? String ?? x["url"] as? String
        return Track(id: id, title: title, artist: artist, album: album, artworkURL: art, streamURL: stream, duration: x["duration"] as? Double)
    }
}
func parsePlaylists(_ data: Data) -> [Playlist] {
    guard let object = try? JSONSerialization.jsonObject(with: data) else { return [] }
    let arrays: [[String: Any]] = {
        if let a = object as? [[String: Any]] { return a }
        if let d = object as? [String: Any] { for key in ["playlists", "items", "data"] { if let a = d[key] as? [[String: Any]] { return a } } }
        return []
    }()
    return arrays.map { x in Playlist(id: String(describing: x["id"] ?? UUID().uuidString), name: String(describing: x["name"] ?? "Плейлист"), description: x["description"] as? String, imageURL: x["imageUrl"] as? String, tracks: []) }
}
